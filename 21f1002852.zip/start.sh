pip install flask
pip install flask-restful
pip install flask-sqlalchemy
python app.py