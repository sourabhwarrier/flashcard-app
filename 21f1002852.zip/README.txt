To run the application, 
enter the following commands in the shell from the root folder of the application 

(1)	cd final-project
(2)	chmod 777 start.sh
(3)	./start.sh