class appConfig():
    SQLALCHEMY_DATABASE_URI = "sqlite:///data/database.sqlite3"
    DEBUG = True